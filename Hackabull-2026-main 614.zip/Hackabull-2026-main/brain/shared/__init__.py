# Shared contract models
